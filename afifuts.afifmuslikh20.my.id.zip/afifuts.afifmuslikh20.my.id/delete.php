<?php
include "database.php";

$query = "DELETE FROM tmhs WHERE id_mhs='$_GET[id_mhs]'";
$data = $db->prepare($query);
$data->execute();

header("location:form.php");
?>
