<?php

include "database.php";

$query ="SELECT * FROM tmhs WHERE id_mhs='$_GET[id_mhs]' ";
$data = $db->prepare($query);
$data->execute();
$person = $data->fetch(PDO::FETCH_OBJ);
?>
<!DOCTYPE html>
<html>
<head>
    <title>COVID-19</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel= "stylesheet" type="text/css" href="css/bootstrap.min.css">
</div>
</head>
<body>
<div class="container">

    <h1 class="text-center">REGISTER<h1>
    <h2 class="text-center">AKSI PEDULI COVID-19<h2>

    <!-- Awal Card Form -->
    <div class="card mt-5">
    <div class="card-header bg-dark text-white">
        Form Aksi Peduli COVID-19
    </div>
    <div class="card-body">
        <form method="post" action="update.php">
        <div class="form-group">
        <label>NIM</label>
        <input type="text" name="nim" class="form-control" placholder="Input NIM Anda disini!" value="<?php echo $tmhs->nim ?>" required>
        </div>
        <div class="form-group">
        <label>Nama</label>
        <input type="text" name="nama" class="form-control" placholder="Input Nama Anda disini!" value="<?php echo $tmhs->nama?>" required>
        </div>
        <div class="form-group">
        <label>Alamat</label>
        <textarea class="form-control" name="alamat" placholder="Input Alamat Anda disini!" value="<?php echo $tmhs->alamat?>"></textarea>
        </div>
        <div class="form-group">
        <label>Program Studi</label>
        <select class="form-control" name="prodi" value="<?php echo $tmhs->prodi?>">
            <option></option>
            <option value="S1-TIF">S1-TIF</option>
            <option value="S1-SI">S1-SI</option>
            <option value="S1-TE">S1-TE</option>
        </select>
        </div>
        <button type="submit" class="btn btn-success" name="bsimpan">Simpan</button>
        <button type="reset" class="btn btn-danger" name="breset">Kosongkan</button>
        </form>        
    </div>
    </div>
    <!-- Akhir Card Form -->