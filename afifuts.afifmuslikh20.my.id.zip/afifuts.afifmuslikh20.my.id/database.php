<?php

$db = new PDO('mysql:host=afifmuslikh20.my.id; dbname=afifmusl_12', 'afifmusl_baru', 'cahbagus30');

?>