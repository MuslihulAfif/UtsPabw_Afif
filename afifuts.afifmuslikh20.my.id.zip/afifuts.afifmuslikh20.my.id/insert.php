<?php
include "database.php";
$query ="INSERT tmhs VALUES('','$_POST[nim]','$_POST[nama]','$_POST[alamat]','$_POST[prodi]')";
$data = $db->prepare($query); //menyiapkan query sql
$data->execute(); //menjalankan perintah query sql

header("location:form.php");
?>