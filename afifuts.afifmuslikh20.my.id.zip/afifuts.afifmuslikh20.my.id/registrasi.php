<?php
    include "database.php";
?>

<!DOCTYPE html>
<html>
<head>
    <title>COVID-19</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel= "stylesheet" type="text/css" href="css/bootstrap.min.css">
</div>
</head>
<body>
<div class="container">
    <!-- Awal Card Form -->
    <div class="card mt-5">
    <div class="card-header bg-dark text-white">
        Form Aksi Peduli COVID-19
    </div>
    <div class="card-body">
        <form method="post" action="insert.php">
        <div class="form-group">
        <label>NIM</label>
        <input type="text" name="nim" class="form-control" placholder="Input NIM Anda disini!" required>
        </div>
        <div class="form-group">
        <label>Nama</label>
        <input type="text" name="nama" class="form-control" placholder="Input Nama Anda disini!" required>
        </div>
        <div class="form-group">
        <label>Alamat</label>
        <textarea class="form-control" name="alamat" placholder="Input Alamat Anda disini!"></textarea>
        </div>
        <div class="form-group">
        <label>Program Studi</label>
        <select class="form-control" name="prodi">
            <option></option>
            <option value="S1-TIF">S1-TIF</option>
            <option value="S1-SI">S1-SI</option>
            <option value="S1-TE">S1-TE</option>
        </select>
        </div>
        <button type="submit" class="btn btn-success" name="bsimpan">Simpan</button>
        <button type="reset" class="btn btn-danger" name="breset">Kosongkan</button>
        </form>        
    </div>
    </div>
    <!-- Akhir Card Form -->
    <!-- Awal Card Table -->
    <div class="card mt-3">
    <div class="card-header bg-dark text-white">
        Daftar Mahasiswa
    </div>
    <div class="card-body">
        <table class="table table-bordered table-striped">
        <tr>
        <th>No</th>
        <th>NIM</th>
        <th>Nama</th>
        <th>Alamat</th>
        <th>Program Studi</th>
        <th>Aksi</th>
        </tr>
        <tbody>
    <?php
    $query ="SELECT * FROM tmhs";
    $data = $db->prepare($query);
    $data->execute();
    $no = 1;
    while($tmhs = $data->fetch(PDO::FETCH_OBJ)){
    ?>
    
    <tr>
        <td><?php echo $id ?></td>
        <td><?php echo $tmhs->nim ?></td>
        <td><?php echo $tmhs->nama ?></td>
        <td><?php echo $tmhs->alamat ?></td>
        <td><?php echo $tmhs->prodi ?></td>
        
        <td><a href="form-edit.php?id_mhs=<?php echo $tmhs->id_mhs?>" class="btn btn-warning">Edit</a>
        <a href="delete.php?id_mhs=<?php echo $tmhs->id_mhs?>" class="btn btn-danger">Hapus</a></td>
    </tr>
    <?php
         $no++;
    } ?>
</tbody>
        </table>      
    </div>
    </div>
    <!-- Akhir Card Table -->
</div>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<body>
</html>